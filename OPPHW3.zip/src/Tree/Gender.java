package Tree;


public enum Gender {
    MALE, FEMALE
}
